CREATE DATABASE SPRING_CATEDRA;
GO

USE SPRING_CATEDRA;
GO

-- 1. CAT�LOGOS BASE INDEPENDIENTES
CREATE TABLE roles (
    id_rol BIGINT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE categorias (
    id_categoria BIGINT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(255),
    activo BIT NOT NULL DEFAULT 1
);

CREATE TABLE modalidades (
    id_modalidad BIGINT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(255)
);

CREATE TABLE clientes (
    id_cliente BIGINT IDENTITY(1,1) PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    documento VARCHAR(20) NOT NULL UNIQUE,
    correo VARCHAR(150) NOT NULL UNIQUE,
    telefono VARCHAR(20),
    direccion VARCHAR(255),
    activo BIT NOT NULL DEFAULT 1
);

CREATE TABLE espacios (
    id_espacio BIGINT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(MAX),
    capacidad INT NOT NULL,
    tipo_espacio VARCHAR(50) NOT NULL,
    activo BIT NOT NULL DEFAULT 1
);

CREATE TABLE servicios_catering (
    id_servicio BIGINT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(MAX),
    precio_persona DECIMAL(10,2) NOT NULL,
    activo BIT NOT NULL DEFAULT 1
);

-- 2. TABLAS TRANSACCIONALES Y INTEGRIDAD REFERENCIAL (RELACIONES)
CREATE TABLE usuarios (
    id_usuario BIGINT IDENTITY(1,1) PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    correo VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    activo BIT NOT NULL DEFAULT 1,
    id_rol BIGINT NOT NULL,
    FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
);

CREATE TABLE cotizaciones (
    id_cotizacion BIGINT IDENTITY(1,1) PRIMARY KEY,
    fecha_cotizacion DATETIME2 NOT NULL,
    monto_total DECIMAL(12,2) NOT NULL,
    estado VARCHAR(30) NOT NULL,
    id_cliente BIGINT NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);

CREATE TABLE detalle_cotizacion (
    id_detalle BIGINT IDENTITY(1,1) PRIMARY KEY,
    tipo_item VARCHAR(30) NOT NULL,
    id_referencia BIGINT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    id_cotizacion BIGINT NOT NULL,
    FOREIGN KEY (id_cotizacion) REFERENCES cotizaciones(id_cotizacion)
);

CREATE TABLE inscripciones (
    id_inscripcion BIGINT IDENTITY(1,1) PRIMARY KEY,
    fecha_inscripcion DATETIME2 NOT NULL,
    estado VARCHAR(30) NOT NULL,
    id_cliente BIGINT NOT NULL,
    id_curso BIGINT,
    id_diplomado BIGINT,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);

CREATE TABLE reservas_espacio (
    id_reserva BIGINT IDENTITY(1,1) PRIMARY KEY,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    motivo VARCHAR(255),
    monto_total DECIMAL(10,2) NOT NULL,
    estado VARCHAR(30) NOT NULL,
    fecha_registro DATETIME2 NOT NULL,
    id_espacio BIGINT NOT NULL,
    id_cliente BIGINT NOT NULL,
    FOREIGN KEY (id_espacio) REFERENCES espacios(id_espacio),
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);

CREATE TABLE pagos (
    id_pago BIGINT IDENTITY(1,1) PRIMARY KEY,
    monto DECIMAL(10,2) NOT NULL,
    fecha_pago DATETIME2 NOT NULL,
    metodo_pago VARCHAR(30) NOT NULL,
    estado VARCHAR(30) NOT NULL,
    id_inscripcion BIGINT,
    id_cotizacion BIGINT,
    FOREIGN KEY (id_cotizacion) REFERENCES cotizaciones(id_cotizacion),
    FOREIGN KEY (id_inscripcion) REFERENCES inscripciones(id_inscripcion)
);

-- 3. TABLA INTERMEDIA DE RELACI�N MUCHOS A MUCHOS
CREATE TABLE espacio_equipamiento (
    id_espacio BIGINT NOT NULL,
    id_equipamiento BIGINT NOT NULL,
    PRIMARY KEY (id_espacio, id_equipamiento),
    FOREIGN KEY (id_espacio) REFERENCES espacios(id_espacio)
);