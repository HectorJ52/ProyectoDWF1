/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import sv.edu.udb.model.Inscripcion;

import java.time.LocalDate;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class InscripcionRequest {

    @NotNull(message = "El cliente es obligatorio")
    private Long idCliente;

    private Long idCurso;

    private Long idDiplomado;

    @NotNull(message = "La fecha de inscripción es obligatoria")
    private LocalDate fechaInscripcion;

    @NotNull(message = "El estado es obligatorio")
    private Inscripcion.EstadoInscripcion estado;
}