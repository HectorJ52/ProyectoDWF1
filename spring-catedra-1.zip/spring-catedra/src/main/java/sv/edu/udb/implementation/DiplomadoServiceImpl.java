/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.DiplomadoRequest;
import sv.edu.udb.controller.response.DiplomadoResponse;
import sv.edu.udb.model.*;
import sv.edu.udb.repository.*;
import sv.edu.udb.service.DiplomadoService;
import sv.edu.udb.service.mapper.DiplomadoMapper;

@Service
@RequiredArgsConstructor
public class DiplomadoServiceImpl implements DiplomadoService {

    private final DiplomadoRepository diplomadoRepository;
    private final CategoriaRepository categoriaRepository;
    private final ModalidadRepository modalidadRepository;
    private final DocenteRepository docenteRepository;
    private final DiplomadoMapper diplomadoMapper;

    @Override
    @Transactional(readOnly = true)
    public Page<DiplomadoResponse> findAllPaginated(Long idCategoria, Long idModalidad, Boolean activo, Pageable pageable) {
        if (idCategoria != null && idModalidad != null) {
            return diplomadoRepository.findByActivoAndCategoriaIdAndModalidadId(activo, idCategoria, idModalidad, pageable)
                    .map(diplomadoMapper::toDiplomadoResponse);
        }
        return diplomadoRepository.findByActivo(activo, pageable).map(diplomadoMapper::toDiplomadoResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public DiplomadoResponse findById(Long id) {
        Diplomado diplomado = diplomadoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Diplomado no encontrado"));
        return diplomadoMapper.toDiplomadoResponse(diplomado);
    }

    @Override
    @Transactional
    public DiplomadoResponse save(DiplomadoRequest request) {
        Categoria cat = categoriaRepository.findById(request.getIdCategoria())
                .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada"));
        Modalidad mod = modalidadRepository.findById(request.getIdModalidad())
                .orElseThrow(() -> new EntityNotFoundException("Modalidad no encontrada"));

        Docente doc = null;
        if (request.getIdDocente() != null) {
            doc = docenteRepository.findById(request.getIdDocente())
                    .orElseThrow(() -> new EntityNotFoundException("Docente no encontrado"));
        }

        Diplomado diplomado = diplomadoMapper.toDiplomado(request);
        diplomado.setCategoria(cat);
        diplomado.setModalidad(mod);
        diplomado.setDocente(doc);
        diplomado.setActivo(true);

        return diplomadoMapper.toDiplomadoResponse(diplomadoRepository.save(diplomado));
    }

    @Override
    @Transactional
    public DiplomadoResponse update(Long id, DiplomadoRequest request) {
        Diplomado diplomadoExistente = diplomadoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Diplomado no encontrado"));

        Categoria cat = categoriaRepository.findById(request.getIdCategoria())
                .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada"));
        Modalidad mod = modalidadRepository.findById(request.getIdModalidad())
                .orElseThrow(() -> new EntityNotFoundException("Modalidad no encontrada"));

        if (request.getIdDocente() != null) {
            Docente doc = docenteRepository.findById(request.getIdDocente())
                    .orElseThrow(() -> new EntityNotFoundException("Docente no encontrado"));
            diplomadoExistente.setDocente(doc);
        } else {
            diplomadoExistente.setDocente(null);
        }

        diplomadoExistente.setCodigo(request.getCodigo());
        diplomadoExistente.setNombre(request.getNombre());
        diplomadoExistente.setDescripcion(request.getDescripcion());
        diplomadoExistente.setCategoria(cat);
        diplomadoExistente.setModalidad(mod);
        diplomadoExistente.setCupoMaximo(request.getCupoMaximo());
        diplomadoExistente.setCosto(request.getCosto());
        diplomadoExistente.setFechaInicio(request.getFechaInicio());
        diplomadoExistente.setFechaFin(request.getFechaFin());
        diplomadoExistente.setHorario(request.getHorario());
        
return
        diplomadoMapper.toDiplomadoResponse(diplomadoRepository.save
        (diplomadoExistente));}
    
@Override
@Transactional
public void delete(Long id) {
    Diplomado diplomado = diplomadoRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Diplomado no encontrado"));
    diplomado.setActivo(false); 
    diplomadoRepository.save(diplomado);
}
}