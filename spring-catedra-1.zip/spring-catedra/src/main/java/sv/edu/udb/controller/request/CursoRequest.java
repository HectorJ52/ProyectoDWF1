/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class CursoRequest {
    @NotBlank(message = "El código del curso es obligatorio")
    @Size(max = 30, message = "El código no debe exceder los 30 caracteres")
    private String codigo;

    @NotBlank(message = "El nombre del curso es obligatorio")
    @Size(max = 200, message = "El nombre no debe exceder los 200 caracteres")
    private String nombre;

    private String descripcion;

    @NotNull(message = "La categoría es obligatoria")
    private Long idCategoria;

    @NotNull(message = "La modalidad es obligatoria")
    private Long idModalidad;

    private Long idDocente;

    @NotNull(message = "El cupo máximo es obligatorio")
    @Positive(message = "El cupo máximo debe ser mayor a cero")
    private Integer cupoMaximo;

    @NotNull(message = "El costo es obligatorio")
    @DecimalMin(value = "0.0", message = "El costo no puede ser un valor negativo")
    private BigDecimal costo;

    @NotNull(message = "La fecha de inicio es obligatoria")
    private LocalDate fechaInicio;

    @NotNull(message = "La fecha de finalización es obligatoria")
    private LocalDate fechaFin;

    @Size(max = 255, message = "El horario no debe exceder los 255 caracteres")
    private String horario;
}