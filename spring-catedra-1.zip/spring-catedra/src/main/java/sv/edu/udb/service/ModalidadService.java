/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sv.edu.udb.service;

import java.util.List;
import sv.edu.udb.model.Modalidad;

public interface ModalidadService {
    List<Modalidad> findAll();
}