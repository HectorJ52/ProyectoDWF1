package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import sv.edu.udb.model.ReservaEspacio.EstadoReserva;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class ReservaEspacioRequest {

    @NotNull(message = "El ID del cliente es obligatorio")
    private Long idCliente;

    @NotNull(message = "El ID del espacio es obligatorio")
    private Long idEspacio;

    @NotNull
    private LocalDate fechaInicio;

    @NotNull
    private LocalDate fechaFin;

    @NotNull
    private LocalTime horaInicio;

    @NotNull
    private LocalTime horaFin;

    @NotNull
    private EstadoReserva estado;

    @NotNull @DecimalMin("0.0")
    private BigDecimal precioTotal;
    private Long idCotizacion;          // Opcional

    private String observaciones;
}

