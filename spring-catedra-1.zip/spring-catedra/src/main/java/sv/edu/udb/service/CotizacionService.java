package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.CotizacionRequest;
import sv.edu.udb.controller.response.CotizacionResponse;
import sv.edu.udb.model.Cotizacion;

public interface CotizacionService {
    Page<CotizacionResponse> findAll(Cotizacion.EstadoCotizacion estado, Long idCliente, Pageable pageable);
    CotizacionResponse findById(Long id);
    CotizacionResponse save(CotizacionRequest request);
    CotizacionResponse update(Long id, CotizacionRequest request);
    void delete(Long id);
}
