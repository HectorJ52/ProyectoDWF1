package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.ServicioCateringRequest;
import sv.edu.udb.controller.response.ServicioCateringResponse;

public interface ServicioCateringService {

    Page<ServicioCateringResponse> findAll(Boolean soloActivos, Pageable pageable);

    ServicioCateringResponse findById(Long id);

    ServicioCateringResponse save(ServicioCateringRequest request);

    ServicioCateringResponse update(Long id, ServicioCateringRequest request);

    void delete(Long id);
}