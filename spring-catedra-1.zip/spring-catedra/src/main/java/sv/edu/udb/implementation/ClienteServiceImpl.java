/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.ClienteRequest;
import sv.edu.udb.controller.response.ClienteResponse;
import sv.edu.udb.model.Cliente;
import sv.edu.udb.repository.ClienteRepository;
import sv.edu.udb.service.ClienteService;
import sv.edu.udb.service.mapper.ClienteMapper;

@Service
@RequiredArgsConstructor
public class ClienteServiceImpl implements ClienteService {

    private final ClienteRepository clienteRepository;
    private final ClienteMapper clienteMapper;

    @Override
    @Transactional(readOnly = true)
    public Page<ClienteResponse> findAllPaginated(Boolean activo, Pageable pageable) {
        return clienteRepository.findByActivo(activo, pageable)
                .map(clienteMapper::toClienteResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public ClienteResponse findById(Long id) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + id));
        return clienteMapper.toClienteResponse(cliente);
    }

    @Override
    @Transactional
    public ClienteResponse save(ClienteRequest request) {
        if (clienteRepository.existsByDocumento(request.getDocumento())) {
            throw new IllegalArgumentException("Ya existe un cliente con el documento: " + request.getDocumento());
        }
        Cliente cliente = clienteMapper.toCliente(request);
        cliente.setActivo(true);
        return clienteMapper.toClienteResponse(clienteRepository.save(cliente));
    }

    @Override
    @Transactional
    public ClienteResponse update(Long id, ClienteRequest request) {
        Cliente clienteExistente = clienteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + id));

        if (!clienteExistente.getDocumento().equals(request.getDocumento())
                && clienteRepository.existsByDocumento(request.getDocumento())) {
            throw new IllegalArgumentException("Ya existe otro cliente con el documento: " + request.getDocumento());
        }

        clienteExistente.setNombres(request.getNombres());
        clienteExistente.setApellidos(request.getApellidos());
        clienteExistente.setDocumento(request.getDocumento());
        clienteExistente.setCorreo(request.getCorreo());
        clienteExistente.setTelefono(request.getTelefono());
        clienteExistente.setDireccion(request.getDireccion());

        return clienteMapper.toClienteResponse(clienteRepository.save(clienteExistente));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + id));
        cliente.setActivo(false);
        clienteRepository.save(cliente);
    }
}