package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.EspacioRequest;
import sv.edu.udb.controller.response.EspacioResponse;
import sv.edu.udb.model.Equipamiento;
import sv.edu.udb.model.Espacio;
import sv.edu.udb.model.Espacio.TipoEspacio;
import sv.edu.udb.repository.EquipamientoRepository;
import sv.edu.udb.repository.EspacioRepository;
import sv.edu.udb.service.EspacioService;
import sv.edu.udb.service.mapper.EspacioMapper;

import java.util.HashSet;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class EspacioServiceImpl implements EspacioService {

    private final EspacioRepository espacioRepository;
    private final EquipamientoRepository equipamientoRepository;
    private final EspacioMapper mapper;

    @Override
    @Transactional(readOnly = true)
    public Page<EspacioResponse> findAll(TipoEspacio tipoEspacio, Boolean soloActivos, Integer capacidadMinima, Pageable pageable) {
        Page<Espacio> page;

        if (tipoEspacio != null) {
            page = espacioRepository.findByTipoEspacio(tipoEspacio, pageable);
        } else if (capacidadMinima != null) {
            page = espacioRepository.findDisponiblesPorCapacidad(capacidadMinima, pageable);
        } else if (Boolean.TRUE.equals(soloActivos)) {
            page = espacioRepository.findByActivoTrue(pageable);
        } else {
            page = espacioRepository.findAll(pageable);
        }

        return page.map(mapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public EspacioResponse findById(Long id) {
        return mapper.toResponse(findEntityById(id));
    }

    @Override
    @Transactional
    public EspacioResponse save(EspacioRequest request) {
        Espacio espacio = Espacio.builder()
                .nombre(request.getNombre())
                .tipoEspacio(request.getTipoEspacio())
                .capacidad(request.getCapacidad())
                .precioHora(request.getPrecioHora())
                .descripcion(request.getDescripcion())
                .activo(request.getActivo() != null ? request.getActivo() : true)
                .build();

        // Asociar equipamientos si se enviaron
        if (request.getIdsEquipamientos() != null && !request.getIdsEquipamientos().isEmpty()) {
            Set<Equipamiento> equipamientos = new HashSet<>();
            for (Long idEquip : request.getIdsEquipamientos()) {
                Equipamiento eq = equipamientoRepository.findById(idEquip)
                        .orElseThrow(() -> new EntityNotFoundException("Equipamiento no encontrado con ID: " + idEquip));
                equipamientos.add(eq);
            }
            espacio.setEquipamientos(equipamientos);
        }

        return mapper.toResponse(espacioRepository.save(espacio));
    }

    @Override
    @Transactional
    public EspacioResponse update(Long id, EspacioRequest request) {
        Espacio espacio = findEntityById(id);

        espacio.setNombre(request.getNombre());
        espacio.setTipoEspacio(request.getTipoEspacio());
        espacio.setCapacidad(request.getCapacidad());
        espacio.setPrecioHora(request.getPrecioHora());
        espacio.setDescripcion(request.getDescripcion());
        if (request.getActivo() != null) {
            espacio.setActivo(request.getActivo());
        }

        // Actualizar equipamientos
        if (request.getIdsEquipamientos() != null) {
            Set<Equipamiento> equipamientos = new HashSet<>();
            for (Long idEquip : request.getIdsEquipamientos()) {
                Equipamiento eq = equipamientoRepository.findById(idEquip)
                        .orElseThrow(() -> new EntityNotFoundException("Equipamiento no encontrado con ID: " + idEquip));
                equipamientos.add(eq);
            }
            espacio.setEquipamientos(equipamientos);
        }

        return mapper.toResponse(espacioRepository.save(espacio));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!espacioRepository.existsById(id)) {
            throw new EntityNotFoundException("Espacio no encontrado con ID: " + id);
        }
        espacioRepository.deleteById(id);
    }

    private Espacio findEntityById(Long id) {
        return espacioRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Espacio no encontrado con ID: " + id));
    }
}