package sv.edu.udb.controller.response;

import lombok.*;
import sv.edu.udb.model.Espacio.TipoEspacio;
import java.math.BigDecimal;
import java.util.Set;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class EspacioResponse {
    private Long id;
    private String nombre;
    private TipoEspacio tipoEspacio;
    private Integer capacidad;
    private BigDecimal precioHora;
    private String descripcion;
    private Boolean activo;
    private Set<Long> idsEquipamientos;
}

