/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package sv.edu.udb.controller.response;

import lombok.*;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class ClienteResponse {
    private Long id;
    private String nombres;
    private String apellidos;
    private String documento;
    private String correo;
    private String telefono;
    private String direccion;
    private Boolean activo;
}