package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import sv.edu.udb.model.Espacio.TipoEspacio;
import java.math.BigDecimal;
import java.util.Set;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class EspacioRequest {

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 100)
    private String nombre;

    @NotNull(message = "El tipo de espacio es obligatorio")
    private TipoEspacio tipoEspacio;

    @NotNull @Positive
    private Integer capacidad;

    @NotNull @DecimalMin("0.0")
    private BigDecimal precioHora;

    private String descripcion;

    private Boolean activo = true;

    private Set<Long> idsEquipamientos;   // IDs de equipamientos a asociar
}
