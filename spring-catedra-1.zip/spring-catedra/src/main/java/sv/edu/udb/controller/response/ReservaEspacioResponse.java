package sv.edu.udb.controller.response;

import lombok.*;
import sv.edu.udb.model.ReservaEspacio.EstadoReserva;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class ReservaEspacioResponse {
    private Long id;
    private Long idCliente;
    private Long idEspacio;
    private String nombreEspacio;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private LocalTime horaInicio;
    private LocalTime horaFin;
    private EstadoReserva estado;
    private BigDecimal precioTotal;
    private Long idCotizacion;
    private String observaciones;
    private LocalDateTime fechaRegistro;
}
