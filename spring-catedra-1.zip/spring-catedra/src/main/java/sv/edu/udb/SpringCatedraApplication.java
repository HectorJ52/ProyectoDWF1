package sv.edu.udb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCatedraApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCatedraApplication.class, args);
	}

}
