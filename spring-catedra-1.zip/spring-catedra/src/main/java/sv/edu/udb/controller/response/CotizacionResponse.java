package sv.edu.udb.controller.response;

import lombok.*;
import sv.edu.udb.model.Cotizacion;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class CotizacionResponse {
    private Long id;
    private Long idCliente;
    private Cotizacion.EstadoCotizacion estado;
    private BigDecimal total;
    private String observaciones;
    private LocalDate fechaRespuesta;
}
