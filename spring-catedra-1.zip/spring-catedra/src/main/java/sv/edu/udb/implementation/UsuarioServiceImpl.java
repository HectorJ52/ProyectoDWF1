package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.UsuarioRequest;
import sv.edu.udb.controller.response.UsuarioResponse;
import sv.edu.udb.model.Rol;
import sv.edu.udb.model.Usuario;
import sv.edu.udb.repository.RolRepository;
import sv.edu.udb.repository.UsuarioRepository;
import sv.edu.udb.service.UsuarioService;

@Service
@RequiredArgsConstructor
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional(readOnly = true)
    public Page<UsuarioResponse> findAll(Pageable pageable) {
        return usuarioRepository.findAll(pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public UsuarioResponse findById(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Usuario no encontrado con ID: " + id
                        )
                );

        return toResponse(usuario);
    }

    @Override
    @Transactional
    public UsuarioResponse save(UsuarioRequest request) {

        if (usuarioRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException(
                    "El nombre de usuario ya está registrado"
            );
        }

        if (usuarioRepository.existsByCorreo(request.getCorreo())) {
            throw new IllegalArgumentException(
                    "El correo ya está registrado"
            );
        }

        Rol rol = rolRepository.findByNombre(request.getRol())
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Rol no encontrado: " + request.getRol()
                        )
                );

        Usuario usuario = Usuario.builder()
                .username(request.getUsername())
                .correo(request.getCorreo())
                .password(passwordEncoder.encode(request.getPassword()))
                .activo(true)
                .rol(rol)
                .build();

        return toResponse(
                usuarioRepository.save(usuario)
        );
    }

    @Override
    @Transactional
    public UsuarioResponse update(Long id, UsuarioRequest request) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Usuario no encontrado con ID: " + id
                        )
                );

        usuarioRepository.findByUsername(request.getUsername())
                .filter(u -> !u.getId().equals(id))
                .ifPresent(u -> {
                    throw new IllegalArgumentException(
                            "El nombre de usuario ya está registrado"
                    );
                });

        usuarioRepository.findByCorreo(request.getCorreo())
                .filter(u -> !u.getId().equals(id))
                .ifPresent(u -> {
                    throw new IllegalArgumentException(
                            "El correo ya está registrado"
                    );
                });

        Rol rol = rolRepository.findByNombre(request.getRol())
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Rol no encontrado: " + request.getRol()
                        )
                );

        usuario.setUsername(request.getUsername());
        usuario.setCorreo(request.getCorreo());
        usuario.setPassword(
                passwordEncoder.encode(request.getPassword())
        );
        usuario.setRol(rol);

        return toResponse(
                usuarioRepository.save(usuario)
        );
    }

    @Override
    @Transactional
    public void delete(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Usuario no encontrado con ID: " + id
                        )
                );

        usuario.setActivo(false);

        usuarioRepository.save(usuario);
    }

    private UsuarioResponse toResponse(Usuario usuario) {

        return UsuarioResponse.builder()
                .id(usuario.getId())
                .username(usuario.getUsername())
                .correo(usuario.getCorreo())
                .activo(usuario.isActivo())
                .rol(usuario.getRol().getNombre())
                .build();
    }
}