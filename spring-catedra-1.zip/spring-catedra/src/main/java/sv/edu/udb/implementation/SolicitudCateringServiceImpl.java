package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.SolicitudCateringRequest;
import sv.edu.udb.controller.response.SolicitudCateringResponse;
import sv.edu.udb.model.*;
import sv.edu.udb.repository.*;
import sv.edu.udb.service.SolicitudCateringService;
import sv.edu.udb.service.mapper.SolicitudCateringMapper;

@Service
@RequiredArgsConstructor
public class SolicitudCateringServiceImpl implements SolicitudCateringService {

    private final SolicitudCateringRepository solicitudRepository;
    private final ClienteRepository clienteRepository;
    private final ServicioCateringRepository servicioRepository;
    private final ReservaEspacioRepository reservaRepository;
    private final CotizacionRepository cotizacionRepository;
    private final SolicitudCateringMapper mapper;

    @Override
    @Transactional(readOnly = true)
    public Page<SolicitudCateringResponse> findAll(SolicitudCatering.EstadoSolicitud estado, Long idCliente, Long idServicio, Pageable pageable) {
        Page<SolicitudCatering> page;

        if (estado != null) {
            page = solicitudRepository.findByEstado(estado, pageable);
        } else if (idCliente != null) {
            page = solicitudRepository.findByClienteId(idCliente, pageable);
        } else if (idServicio != null) {
            page = solicitudRepository.findByServicioId(idServicio, pageable);
        } else {
            page = solicitudRepository.findAll(pageable);
        }

        return page.map(mapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public SolicitudCateringResponse findById(Long id) {
        return mapper.toResponse(findEntityById(id));
    }

    @Override
    @Transactional
    public SolicitudCateringResponse save(SolicitudCateringRequest request) {
        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));

        ServicioCatering servicio = servicioRepository.findById(request.getIdServicio())
                .orElseThrow(() -> new EntityNotFoundException("Servicio de catering no encontrado con ID: " + request.getIdServicio()));

        ReservaEspacio reserva = null;
        if (request.getIdReservaEspacio() != null) {
            reserva = reservaRepository.findById(request.getIdReservaEspacio())
                    .orElseThrow(() -> new EntityNotFoundException("Reserva de espacio no encontrada"));
        }

        Cotizacion cotizacion = null;
        if (request.getIdCotizacion() != null) {
            cotizacion = cotizacionRepository.findById(request.getIdCotizacion())
                    .orElseThrow(() -> new EntityNotFoundException("Cotización no encontrada"));
        }

        SolicitudCatering solicitud = SolicitudCatering.builder()
                .cliente(cliente)
                .servicio(servicio)
                .numeroAsistentes(request.getNumeroAsistentes())
                .menu(request.getMenu())
                .fecha(request.getFecha())
                .hora(request.getHora())
                .lugar(request.getLugar())
                .estado(request.getEstado())
                .precioTotal(request.getPrecioTotal())
                .reservaEspacio(reserva)
                .cotizacion(cotizacion)
                .build();

        return mapper.toResponse(solicitudRepository.save(solicitud));
    }

    @Override
    @Transactional
    public SolicitudCateringResponse update(Long id, SolicitudCateringRequest request) {
        SolicitudCatering solicitud = findEntityById(id);

        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado"));

        ServicioCatering servicio = servicioRepository.findById(request.getIdServicio())
                .orElseThrow(() -> new EntityNotFoundException("Servicio de catering no encontrado"));

        solicitud.setCliente(cliente);
        solicitud.setServicio(servicio);
        solicitud.setNumeroAsistentes(request.getNumeroAsistentes());
        solicitud.setMenu(request.getMenu());
        solicitud.setFecha(request.getFecha());
        solicitud.setHora(request.getHora());
        solicitud.setLugar(request.getLugar());
        solicitud.setEstado(request.getEstado());
        solicitud.setPrecioTotal(request.getPrecioTotal());

        if (request.getIdReservaEspacio() != null) {
            ReservaEspacio reserva = reservaRepository.findById(request.getIdReservaEspacio())
                    .orElseThrow(() -> new EntityNotFoundException("Reserva de espacio no encontrada"));
            solicitud.setReservaEspacio(reserva);
        } else {
            solicitud.setReservaEspacio(null);
        }

        if (request.getIdCotizacion() != null) {
            Cotizacion cotizacion = cotizacionRepository.findById(request.getIdCotizacion())
                    .orElseThrow(() -> new EntityNotFoundException("Cotización no encontrada"));
            solicitud.setCotizacion(cotizacion);
        } else {
            solicitud.setCotizacion(null);
        }

        return mapper.toResponse(solicitudRepository.save(solicitud));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!solicitudRepository.existsById(id)) {
            throw new EntityNotFoundException("Solicitud de catering no encontrada con ID: " + id);
        }
        solicitudRepository.deleteById(id);
    }

    private SolicitudCatering findEntityById(Long id) {
        return solicitudRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Solicitud de catering no encontrada con ID: " + id));
    }
}