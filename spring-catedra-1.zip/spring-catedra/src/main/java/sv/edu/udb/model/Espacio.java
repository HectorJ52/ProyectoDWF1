package sv.edu.udb.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "espacios")
@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class Espacio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_espacio")
    private Long id;

    @NotBlank(message = "El nombre del espacio es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar los 100 caracteres")
    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @NotNull(message = "El tipo de espacio es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_espacio", nullable = false, length = 50)
    private TipoEspacio tipoEspacio;

    @NotNull(message = "La capacidad es obligatoria")
    @Positive(message = "La capacidad debe ser un número positivo")
    @Column(name = "capacidad", nullable = false)
    private Integer capacidad;

    @NotNull(message = "El precio por hora es obligatorio")
    @DecimalMin(value = "0.0", inclusive = true, message = "El precio no puede ser negativo")
    @Column(name = "precio_hora", nullable = false, precision = 10, scale = 2)
    private BigDecimal precioHora;

    @Lob
    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "activo", nullable = false)
    private Boolean activo = true;

    @ManyToMany
    @JoinTable(
            name = "espacio_equipamiento",
            joinColumns = @JoinColumn(name = "id_espacio"),
            inverseJoinColumns = @JoinColumn(name = "id_equipamiento")
    )
    @Builder.Default
    private Set<Equipamiento> equipamientos = new HashSet<>();

    public enum TipoEspacio {
        AUDITORIO,
        SALA_REUNIONES,
        LABORATORIO,
        AULA,
        SALA_MULTIMEDIA
    }
}
