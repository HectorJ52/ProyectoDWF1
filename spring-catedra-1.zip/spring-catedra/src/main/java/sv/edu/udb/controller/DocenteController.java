/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sv.edu.udb.model.Docente;
import sv.edu.udb.repository.DocenteRepository;

@RestController
@RequestMapping("/api/docentes")
@RequiredArgsConstructor
@Tag(name = "Docentes", description = "Endpoints para el mantenimiento de Docentes")
public class DocenteController {

    private final DocenteRepository docenteRepository;

    @GetMapping
    @Operation(summary = "Listar docentes de forma paginada y ordenada")
    public ResponseEntity<Page<Docente>> getAll(
            @RequestParam(defaultValue = "true") Boolean activo,
            @PageableDefault(size = 10, sort = "apellidos") Pageable pageable) {
        return ResponseEntity.ok(docenteRepository.findByActivo(activo, pageable));
    }

    @PostMapping
    @Operation(summary = "Registrar un nuevo docente")
    public ResponseEntity<Docente> create(@Valid @RequestBody Docente docente) {
        docente.setActivo(true);
        return new ResponseEntity<>(docenteRepository.save(docente), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener docente por ID")
    public ResponseEntity<Docente> getById(@PathVariable Long id) {
        return ResponseEntity.ok(docenteRepository.findById(id)
                .orElseThrow(() -> new jakarta.persistence.EntityNotFoundException("Docente no encontrado")));
    }
}