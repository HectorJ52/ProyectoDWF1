/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.ClienteRequest;
import sv.edu.udb.controller.response.ClienteResponse;

public interface ClienteService {
    Page<ClienteResponse> findAllPaginated(Boolean activo, Pageable pageable);
    ClienteResponse findById(Long id);
    ClienteResponse save(ClienteRequest clienteRequest);
    ClienteResponse update(Long id, ClienteRequest clienteRequest);
    void delete(Long id);
}