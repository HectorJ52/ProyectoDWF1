package sv.edu.udb.exception;

public class EspacioOcupadoException extends RuntimeException
{
    public EspacioOcupadoException(String message)
    {
        super(message);
    }
}

