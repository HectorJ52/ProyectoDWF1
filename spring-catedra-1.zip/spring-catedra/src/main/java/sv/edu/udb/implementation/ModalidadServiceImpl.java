/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.implementation;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.model.Modalidad;
import sv.edu.udb.repository.ModalidadRepository;
import sv.edu.udb.service.ModalidadService;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ModalidadServiceImpl implements ModalidadService {
    private final ModalidadRepository modalidadRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Modalidad> findAll() {
        return modalidadRepository.findAll();
    }
}