/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sv.edu.udb.service.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import sv.edu.udb.controller.request.CursoRequest;
import sv.edu.udb.controller.response.CursoResponse;
import sv.edu.udb.model.Curso;

@Mapper(componentModel = "spring")
public interface CursoMapper {
    @Mapping(target = "idCategoria", source = "categoria.id")
    @Mapping(target = "nombreCategoria", source = "categoria.nombre")
    @Mapping(target = "idModalidad", source = "modalidad.id")
    @Mapping(target = "nombreModalidad", source = "modalidad.nombre")
    @Mapping(target = "idDocente", source = "docente.id")
    @Mapping(target = "nombreCompletoDocente", expression = "java(data.getDocente() != null ? data.getDocente().getNombres() + \" \" + data.getDocente().getApellidos() : null)")
    CursoResponse toCursoResponse(Curso data);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "activo", ignore = true)
    @Mapping(target = "categoria", ignore = true)
    @Mapping(target = "modalidad", ignore = true)
    @Mapping(target = "docente", ignore = true)
    Curso toCurso(CursoRequest request);
}