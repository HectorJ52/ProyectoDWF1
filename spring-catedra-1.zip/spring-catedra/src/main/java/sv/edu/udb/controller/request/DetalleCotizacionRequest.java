package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import sv.edu.udb.model.DetalleCotizacion;

import java.math.BigDecimal;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class DetalleCotizacionRequest {

    @NotNull(message = "La cotización es obligatoria")
    private Long idCotizacion;

    @NotNull(message = "El tipo de ítem es obligatorio")
    private DetalleCotizacion.TipoItem tipoItem;

    @NotNull(message = "La referencia del ítem es obligatoria")
    @Positive(message = "La referencia del ítem debe ser positiva")
    private Long idReferencia;

    @NotNull(message = "La cantidad es obligatoria")
    @Positive(message = "La cantidad debe ser positiva")
    private Integer cantidad;

    @NotNull(message = "El precio unitario es obligatorio")
    @DecimalMin(value = "0.0", inclusive = true, message = "El precio unitario no puede ser negativo")
    private BigDecimal precioUnitario;
}
