/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.DiplomadoRequest;
import sv.edu.udb.controller.response.DiplomadoResponse;

public interface DiplomadoService {
    Page<DiplomadoResponse> findAllPaginated(Long idCategoria, Long idModalidad, Boolean activo, Pageable pageable);
    DiplomadoResponse findById(Long id);
    DiplomadoResponse save(DiplomadoRequest diplomadoRequest);
    DiplomadoResponse update(Long id, DiplomadoRequest diplomadoRequest);
    void delete(Long id);
}