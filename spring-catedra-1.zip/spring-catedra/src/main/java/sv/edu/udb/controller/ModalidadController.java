/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sv.edu.udb.model.Modalidad;
import sv.edu.udb.service.ModalidadService;
import java.util.List;

@RestController
@RequestMapping("/api/modalidades")
@RequiredArgsConstructor
@Tag(name = "Modalidades", description = "Endpoints para consultar el catálogo de Modalidades")
public class ModalidadController {
    private final ModalidadService modalidadService;

    @GetMapping
    @Operation(summary = "Listar todas las modalidades disponibles")
    public ResponseEntity<List<Modalidad>> getAll() {
        return ResponseEntity.ok(modalidadService.findAll());
    }
}