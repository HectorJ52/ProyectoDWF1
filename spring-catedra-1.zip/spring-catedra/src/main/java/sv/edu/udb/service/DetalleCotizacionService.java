package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.DetalleCotizacionRequest;
import sv.edu.udb.controller.response.DetalleCotizacionResponse;

public interface DetalleCotizacionService {
    Page<DetalleCotizacionResponse> findAll(Long idCotizacion, Pageable pageable);
    DetalleCotizacionResponse findById(Long id);
    DetalleCotizacionResponse save(DetalleCotizacionRequest request);
    DetalleCotizacionResponse update(Long id, DetalleCotizacionRequest request);
    void delete(Long id);
}
