package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.EquipamientoRequest;
import sv.edu.udb.controller.response.EquipamientoResponse;

public interface EquipamientoService {

    Page<EquipamientoResponse> findAll(Pageable pageable);

    EquipamientoResponse findById(Long id);

    EquipamientoResponse save(EquipamientoRequest request);

    EquipamientoResponse update(Long id, EquipamientoRequest request);

    void delete(Long id);
}