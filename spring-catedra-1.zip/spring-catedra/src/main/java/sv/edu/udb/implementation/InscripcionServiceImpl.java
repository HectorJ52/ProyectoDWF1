/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.InscripcionRequest;
import sv.edu.udb.controller.response.InscripcionResponse;
import sv.edu.udb.model.*;
import sv.edu.udb.repository.*;
import sv.edu.udb.service.InscripcionService;
import sv.edu.udb.service.mapper.InscripcionMapper;

@Service
@RequiredArgsConstructor
public class InscripcionServiceImpl implements InscripcionService {

    private final InscripcionRepository inscripcionRepository;
    private final ClienteRepository clienteRepository;
    private final CursoRepository cursoRepository;
    private final DiplomadoRepository diplomadoRepository;
    private final InscripcionMapper inscripcionMapper;

    @Override
    @Transactional(readOnly = true)
    public Page<InscripcionResponse> findAllPaginated(Boolean activo, Long idCliente, Pageable pageable) {
        if (idCliente != null) {
            return inscripcionRepository.findByClienteId(idCliente, pageable)
                    .map(inscripcionMapper::toInscripcionResponse);
        }
        return inscripcionRepository.findByActivo(activo, pageable)
                .map(inscripcionMapper::toInscripcionResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public InscripcionResponse findById(Long id) {
        Inscripcion inscripcion = inscripcionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Inscripción no encontrada con ID: " + id));
        return inscripcionMapper.toInscripcionResponse(inscripcion);
    }

    @Override
    @Transactional
    public InscripcionResponse save(InscripcionRequest request) {
        // Regla 1: exactamente un Curso o un Diplomado
        boolean tieneCurso = request.getIdCurso() != null;
        boolean tieneDiplomado = request.getIdDiplomado() != null;
        if (tieneCurso == tieneDiplomado) {
            throw new IllegalArgumentException("La inscripción debe tener exactamente un Curso o un Diplomado, no ambos ni ninguno");
        }

        // Regla 2: el cliente debe existir y estar activo
        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));
        if (Boolean.FALSE.equals(cliente.getActivo())) {
            throw new IllegalStateException("El cliente está inactivo y no puede inscribirse");
        }

        Inscripcion inscripcion = inscripcionMapper.toInscripcion(request);
        inscripcion.setCliente(cliente);
        inscripcion.setActivo(true);

        // Regla 3: validar cupo si es Curso
        if (tieneCurso) {
            Curso curso = cursoRepository.findById(request.getIdCurso())
                    .orElseThrow(() -> new EntityNotFoundException("Curso no encontrado con ID: " + request.getIdCurso()));
            if (Boolean.FALSE.equals(curso.getActivo())) {
                throw new IllegalStateException("El curso está inactivo");
            }
            long inscritos = inscripcionRepository.countByCursoIdAndEstadoNot(
                    curso.getId(), Inscripcion.EstadoInscripcion.CANCELADA);
            if (inscritos >= curso.getCupoMaximo()) {
                throw new IllegalStateException("El curso ha alcanzado su cupo máximo de " + curso.getCupoMaximo());
            }
            inscripcion.setCurso(curso);
            inscripcion.setMonto(curso.getCosto());
        }

        // Regla 4: validar cupo si es Diplomado
        if (tieneDiplomado) {
            Diplomado diplomado = diplomadoRepository.findById(request.getIdDiplomado())
                    .orElseThrow(() -> new EntityNotFoundException("Diplomado no encontrado con ID: " + request.getIdDiplomado()));
            if (Boolean.FALSE.equals(diplomado.getActivo())) {
                throw new IllegalStateException("El diplomado está inactivo");
            }
            long inscritos = inscripcionRepository.countByDiplomadoIdAndEstadoNot(
                    diplomado.getId(), Inscripcion.EstadoInscripcion.CANCELADA);
            if (inscritos >= diplomado.getCupoMaximo()) {
                throw new IllegalStateException("El diplomado ha alcanzado su cupo máximo de " + diplomado.getCupoMaximo());
            }
            inscripcion.setDiplomado(diplomado);
            inscripcion.setMonto(diplomado.getCosto());
        }

        return inscripcionMapper.toInscripcionResponse(inscripcionRepository.save(inscripcion));
    }

    @Override
    @Transactional
    public InscripcionResponse update(Long id, InscripcionRequest request) {
        Inscripcion inscripcionExistente = inscripcionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Inscripción no encontrada con ID: " + id));

        // Regla 1: exactamente un Curso o un Diplomado
        boolean tieneCurso = request.getIdCurso() != null;
        boolean tieneDiplomado = request.getIdDiplomado() != null;
        if (tieneCurso == tieneDiplomado) {
            throw new IllegalArgumentException("La inscripción debe tener exactamente un Curso o un Diplomado, no ambos ni ninguno");
        }

        // Cliente
        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));
        if (Boolean.FALSE.equals(cliente.getActivo())) {
            throw new IllegalStateException("El cliente está inactivo");
        }
        inscripcionExistente.setCliente(cliente);

        // Curso o Diplomado
        if (tieneCurso) {
            Curso curso = cursoRepository.findById(request.getIdCurso())
                    .orElseThrow(() -> new EntityNotFoundException("Curso no encontrado con ID: " + request.getIdCurso()));
            if (Boolean.FALSE.equals(curso.getActivo())) {
                throw new IllegalStateException("El curso está inactivo");
            }
            if (inscripcionExistente.getCurso() == null
                    || !inscripcionExistente.getCurso().getId().equals(curso.getId())) {
                long inscritos = inscripcionRepository.countByCursoIdAndEstadoNot(
                        curso.getId(), Inscripcion.EstadoInscripcion.CANCELADA);
                if (inscritos >= curso.getCupoMaximo()) {
                    throw new IllegalStateException("El curso ha alcanzado su cupo máximo");
                }
            }
            inscripcionExistente.setCurso(curso);
            inscripcionExistente.setDiplomado(null);
            inscripcionExistente.setMonto(curso.getCosto());
        }

        if (tieneDiplomado) {
            Diplomado diplomado = diplomadoRepository.findById(request.getIdDiplomado())
                    .orElseThrow(() -> new EntityNotFoundException("Diplomado no encontrado con ID: " + request.getIdDiplomado()));
            if (Boolean.FALSE.equals(diplomado.getActivo())) {
                throw new IllegalStateException("El diplomado está inactivo");
            }
            if (inscripcionExistente.getDiplomado() == null
                    || !inscripcionExistente.getDiplomado().getId().equals(diplomado.getId())) {
                long inscritos = inscripcionRepository.countByDiplomadoIdAndEstadoNot(
                        diplomado.getId(), Inscripcion.EstadoInscripcion.CANCELADA);
                if (inscritos >= diplomado.getCupoMaximo()) {
                    throw new IllegalStateException("El diplomado ha alcanzado su cupo máximo");
                }
            }
            inscripcionExistente.setDiplomado(diplomado);
            inscripcionExistente.setCurso(null);
            inscripcionExistente.setMonto(diplomado.getCosto());
        }

        inscripcionExistente.setFechaInscripcion(request.getFechaInscripcion());
        inscripcionExistente.setEstado(request.getEstado());

        return inscripcionMapper.toInscripcionResponse(inscripcionRepository.save(inscripcionExistente));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Inscripcion inscripcion = inscripcionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Inscripción no encontrada con ID: " + id));
        inscripcion.setActivo(false);
        inscripcionRepository.save(inscripcion);
    }
}