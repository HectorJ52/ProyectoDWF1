/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.CursoRequest;
import sv.edu.udb.controller.response.CursoResponse;
import sv.edu.udb.model.*;
import sv.edu.udb.repository.*;
import sv.edu.udb.service.CursoService;
import sv.edu.udb.service.mapper.CursoMapper;

@Service
@RequiredArgsConstructor
public class CursoServiceImpl implements CursoService {

    private final CursoRepository cursoRepository;
    private final CategoriaRepository categoriaRepository;
    private final ModalidadRepository modalidadRepository;
    private final DocenteRepository docenteRepository;
    private final CursoMapper cursoMapper;

    @Override
    @Transactional(readOnly = true)
    public Page<CursoResponse> findAllPaginated(Long idCategoria, Long idModalidad, Boolean activo, Pageable pageable) {
        if (idCategoria != null && idModalidad != null) {
            return cursoRepository.findByActivoAndCategoriaIdAndModalidadId(activo, idCategoria, idModalidad, pageable)
                    .map(cursoMapper::toCursoResponse);
        }
        return cursoRepository.findByActivo(activo, pageable).map(cursoMapper::toCursoResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public CursoResponse findById(Long id) {
        Curso curso = cursoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Curso no encontrado con ID: " + id));
        return cursoMapper.toCursoResponse(curso);
    }

    @Override
    @Transactional
    public CursoResponse save(CursoRequest request) {
        Categoria cat = categoriaRepository.findById(request.getIdCategoria())
                .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada"));
        Modalidad mod = modalidadRepository.findById(request.getIdModalidad())
                .orElseThrow(() -> new EntityNotFoundException("Modalidad no encontrada"));

        Docente doc = null;
        if (request.getIdDocente() != null) {
            doc = docenteRepository.findById(request.getIdDocente())
                    .orElseThrow(() -> new EntityNotFoundException("Docente no encontrado"));
        }

        Curso curso = cursoMapper.toCurso(request);
        curso.setCategoria(cat);
        curso.setModalidad(mod);
        curso.setDocente(doc);
        curso.setActivo(true);

        return cursoMapper.toCursoResponse(cursoRepository.save(curso));
    }

    @Override
    @Transactional
    public CursoResponse update(Long id, CursoRequest request) {
        Curso cursoExistente = cursoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Curso no encontrado"));

        Categoria cat = categoriaRepository.findById(request.getIdCategoria())
                .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada"));
        Modalidad mod = modalidadRepository.findById(request.getIdModalidad())
                .orElseThrow(() -> new EntityNotFoundException("Modalidad no encontrada"));

        if (request.getIdDocente() != null) {
            Docente doc = docenteRepository.findById(request.getIdDocente())
                    .orElseThrow(() -> new EntityNotFoundException("Docente no encontrado"));
            cursoExistente.setDocente(doc);
        } else {
            cursoExistente.setDocente(null);
        }

        cursoExistente.setCodigo(request.getCodigo());
        cursoExistente.setNombre(request.getNombre());
        cursoExistente.setDescripcion(request.getDescripcion());
        cursoExistente.setCategoria(cat);
        cursoExistente.setModalidad(mod);
        cursoExistente.setCupoMaximo(request.getCupoMaximo());
        cursoExistente.setCosto(request.getCosto());
        cursoExistente.setFechaInicio(request.getFechaInicio());
        cursoExistente.setFechaFin(request.getFechaFin());
        cursoExistente.setHorario(request.getHorario());

        return cursoMapper.toCursoResponse(cursoRepository.save(cursoExistente));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Curso curso = cursoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Curso no encontrado"));
        curso.setActivo(false); // Eliminado lógico por estado solicitado
        cursoRepository.save(curso);
    }
}