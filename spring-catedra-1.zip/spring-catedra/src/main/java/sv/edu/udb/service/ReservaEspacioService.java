package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.ReservaEspacioRequest;
import sv.edu.udb.controller.response.ReservaEspacioResponse;
import sv.edu.udb.model.ReservaEspacio.EstadoReserva;

import java.time.LocalDate;
import java.time.LocalTime;

public interface ReservaEspacioService {

    Page<ReservaEspacioResponse> findAll(EstadoReserva estado, Long idEspacio, Long idCliente, Pageable pageable);

    ReservaEspacioResponse findById(Long id);

    ReservaEspacioResponse save(ReservaEspacioRequest request);

    ReservaEspacioResponse update(Long id, ReservaEspacioRequest request);

    void delete(Long id);

    /**
     * Verifica si un espacio está disponible en el rango de fechas y horas indicado.
     * @return true si está disponible, false si hay conflicto
     */
    boolean verificarDisponibilidad(Long idEspacio, LocalDate fechaInicio, LocalDate fechaFin,
                                    LocalTime horaInicio, LocalTime horaFin);
}