package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.UsuarioRequest;
import sv.edu.udb.controller.response.UsuarioResponse;

public interface UsuarioService {

    Page<UsuarioResponse> findAll(Pageable pageable);

    UsuarioResponse findById(Long id);

    UsuarioResponse save(UsuarioRequest request);

    UsuarioResponse update(Long id, UsuarioRequest request);

    void delete(Long id);
}