/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.CursoRequest;
import sv.edu.udb.controller.response.CursoResponse;

public interface CursoService {
    Page<CursoResponse> findAllPaginated(Long idCategoria, Long idModalidad, Boolean activo, Pageable pageable);
    CursoResponse findById(Long id);
    CursoResponse save(CursoRequest cursoRequest);
    CursoResponse update(Long id, CursoRequest cursoRequest);
    void delete(Long id);
}