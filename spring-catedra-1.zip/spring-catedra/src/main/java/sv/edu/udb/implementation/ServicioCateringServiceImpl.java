package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.ServicioCateringRequest;
import sv.edu.udb.controller.response.ServicioCateringResponse;
import sv.edu.udb.model.ServicioCatering;
import sv.edu.udb.repository.ServicioCateringRepository;
import sv.edu.udb.service.ServicioCateringService;
import sv.edu.udb.service.mapper.ServicioCateringMapper;

@Service
@RequiredArgsConstructor
public class ServicioCateringServiceImpl implements ServicioCateringService {

    private final ServicioCateringRepository repository;
    private final ServicioCateringMapper mapper;

    @Override
    @Transactional(readOnly = true)
    public Page<ServicioCateringResponse> findAll(Boolean soloActivos, Pageable pageable) {
        Page<ServicioCatering> page;

        if (Boolean.TRUE.equals(soloActivos)) {
            page = repository.findByActivoTrue(pageable);
        } else {
            page = repository.findAll(pageable);
        }

        return page.map(mapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public ServicioCateringResponse findById(Long id) {
        return mapper.toResponse(findEntityById(id));
    }

    @Override
    @Transactional
    public ServicioCateringResponse save(ServicioCateringRequest request) {
        if (repository.existsByNombreIgnoreCase(request.getNombre())) {
            throw new IllegalArgumentException("Ya existe un servicio de catering con el nombre: " + request.getNombre());
        }

        ServicioCatering servicio = ServicioCatering.builder()
                .nombre(request.getNombre())
                .descripcion(request.getDescripcion())
                .precioPersona(request.getPrecioPersona())
                .activo(request.getActivo() != null ? request.getActivo() : true)
                .build();

        return mapper.toResponse(repository.save(servicio));
    }

    @Override
    @Transactional
    public ServicioCateringResponse update(Long id, ServicioCateringRequest request) {
        ServicioCatering servicio = findEntityById(id);

        servicio.setNombre(request.getNombre());
        servicio.setDescripcion(request.getDescripcion());
        servicio.setPrecioPersona(request.getPrecioPersona());
        if (request.getActivo() != null) {
            servicio.setActivo(request.getActivo());
        }

        return mapper.toResponse(repository.save(servicio));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new EntityNotFoundException("Servicio de catering no encontrado con ID: " + id);
        }
        repository.deleteById(id);
    }

    private ServicioCatering findEntityById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Servicio de catering no encontrado con ID: " + id));
    }
}