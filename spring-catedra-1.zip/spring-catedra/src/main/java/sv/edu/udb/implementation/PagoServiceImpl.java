package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.PagoRequest;
import sv.edu.udb.controller.response.PagoResponse;
import sv.edu.udb.exception.SaldoInsuficienteException;
import sv.edu.udb.model.Cotizacion;
import sv.edu.udb.model.Inscripcion;
import sv.edu.udb.model.Pago;
import sv.edu.udb.repository.CotizacionRepository;
import sv.edu.udb.repository.InscripcionRepository;
import sv.edu.udb.repository.PagoRepository;
import sv.edu.udb.service.PagoService;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PagoServiceImpl implements PagoService {

    private final PagoRepository pagoRepository;
    private final InscripcionRepository inscripcionRepository;
    private final CotizacionRepository cotizacionRepository;

    @Override
    @Transactional(readOnly = true)
    public Page<PagoResponse> findAll(Pageable pageable) {
        return pagoRepository.findAll(pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public PagoResponse findById(Long id) {
        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Pago no encontrado con ID: " + id
                        )
                );

        return toResponse(pago);
    }

    @Override
    @Transactional
    public PagoResponse save(PagoRequest request) {

        validarReferencia(request);

        Inscripcion inscripcion = null;
        Cotizacion cotizacion = null;

        if (request.getIdInscripcion() != null) {

            inscripcion = inscripcionRepository
                    .findById(request.getIdInscripcion())
                    .orElseThrow(() ->
                            new EntityNotFoundException(
                                    "Inscripción no encontrada con ID: "
                                            + request.getIdInscripcion()
                            )
                    );

            validarSaldoInscripcion(
                    inscripcion,
                    request.getMonto(),
                    null
            );
        }

        if (request.getIdCotizacion() != null) {

            cotizacion = cotizacionRepository
                    .findById(request.getIdCotizacion())
                    .orElseThrow(() ->
                            new EntityNotFoundException(
                                    "Cotización no encontrada con ID: "
                                            + request.getIdCotizacion()
                            )
                    );

            validarSaldoCotizacion(
                    cotizacion,
                    request.getMonto(),
                    null
            );
        }

        Pago pago = Pago.builder()
                .inscripcion(inscripcion)
                .cotizacion(cotizacion)
                .monto(request.getMonto())
                .fechaPago(request.getFechaPago())
                .build();

        return toResponse(
                pagoRepository.save(pago)
        );
    }

    @Override
    @Transactional
    public PagoResponse update(Long id, PagoRequest request) {

        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                "Pago no encontrado con ID: " + id
                        )
                );

        validarReferencia(request);

        Inscripcion inscripcion = null;
        Cotizacion cotizacion = null;

        if (request.getIdInscripcion() != null) {

            inscripcion = inscripcionRepository
                    .findById(request.getIdInscripcion())
                    .orElseThrow(() ->
                            new EntityNotFoundException(
                                    "Inscripción no encontrada con ID: "
                                            + request.getIdInscripcion()
                            )
                    );

            validarSaldoInscripcion(
                    inscripcion,
                    request.getMonto(),
                    id
            );
        }

        if (request.getIdCotizacion() != null) {

            cotizacion = cotizacionRepository
                    .findById(request.getIdCotizacion())
                    .orElseThrow(() ->
                            new EntityNotFoundException(
                                    "Cotización no encontrada con ID: "
                                            + request.getIdCotizacion()
                            )
                    );

            validarSaldoCotizacion(
                    cotizacion,
                    request.getMonto(),
                    id
            );
        }

        pago.setInscripcion(inscripcion);
        pago.setCotizacion(cotizacion);
        pago.setMonto(request.getMonto());
        pago.setFechaPago(request.getFechaPago());

        return toResponse(
                pagoRepository.save(pago)
        );
    }

    @Override
    @Transactional
    public void delete(Long id) {

        if (!pagoRepository.existsById(id)) {
            throw new EntityNotFoundException(
                    "Pago no encontrado con ID: " + id
            );
        }

        pagoRepository.deleteById(id);
    }

    private void validarReferencia(PagoRequest request) {

        boolean tieneInscripcion =
                request.getIdInscripcion() != null;

        boolean tieneCotizacion =
                request.getIdCotizacion() != null;

        if (tieneInscripcion == tieneCotizacion) {
            throw new IllegalArgumentException(
                    "El pago debe pertenecer a una inscripción o a una cotización, pero no a ambas"
            );
        }
    }

    private void validarSaldoInscripcion(
            Inscripcion inscripcion,
            BigDecimal nuevoPago,
            Long idPagoActual
    ) {

        BigDecimal total = inscripcion.getMonto();

        if (total == null) {
            throw new IllegalArgumentException(
                    "La inscripción no tiene un monto definido"
            );
        }

        List<Pago> pagos =
                pagoRepository.findByInscripcionId(
                        inscripcion.getId()
                );

        BigDecimal totalPagado =
                pagos.stream()
                        .filter(p ->
                                idPagoActual == null
                                        || !p.getId().equals(idPagoActual)
                        )
                        .map(Pago::getMonto)
                        .reduce(
                                BigDecimal.ZERO,
                                BigDecimal::add
                        );

        BigDecimal saldoPendiente =
                total.subtract(totalPagado);

        if (nuevoPago.compareTo(saldoPendiente) > 0) {
            throw new SaldoInsuficienteException(
                    "El pago no puede superar el saldo pendiente de la inscripción"
            );
        }
    }

    private void validarSaldoCotizacion(
            Cotizacion cotizacion,
            BigDecimal nuevoPago,
            Long idPagoActual
    ) {

        BigDecimal total = cotizacion.getTotal();

        if (total == null) {
            throw new IllegalArgumentException(
                    "La cotización no tiene un total definido"
            );
        }

        List<Pago> pagos =
                pagoRepository.findByCotizacionId(
                        cotizacion.getId()
                );

        BigDecimal totalPagado =
                pagos.stream()
                        .filter(p ->
                                idPagoActual == null
                                        || !p.getId().equals(idPagoActual)
                        )
                        .map(Pago::getMonto)
                        .reduce(
                                BigDecimal.ZERO,
                                BigDecimal::add
                        );

        BigDecimal saldoPendiente =
                total.subtract(totalPagado);

        if (nuevoPago.compareTo(saldoPendiente) > 0) {
            throw new SaldoInsuficienteException(
                    "El pago no puede superar el saldo pendiente de la cotización"
            );
        }
    }

    private PagoResponse toResponse(Pago pago) {

        return PagoResponse.builder()
                .id(pago.getId())
                .idInscripcion(
                        pago.getInscripcion() != null
                                ? pago.getInscripcion().getId()
                                : null
                )
                .idCotizacion(
                        pago.getCotizacion() != null
                                ? pago.getCotizacion().getId()
                                : null
                )
                .monto(pago.getMonto())
                .fechaPago(pago.getFechaPago())
                .build();
    }
}