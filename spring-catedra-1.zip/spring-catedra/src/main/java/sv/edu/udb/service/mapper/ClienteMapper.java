/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author melga
 */
package sv.edu.udb.service.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import sv.edu.udb.controller.request.ClienteRequest;
import sv.edu.udb.controller.response.ClienteResponse;
import sv.edu.udb.model.Cliente;

@Mapper(componentModel = "spring")
public interface ClienteMapper {

    ClienteResponse toClienteResponse(Cliente data);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "activo", ignore = true)
    Cliente toCliente(ClienteRequest request);
}