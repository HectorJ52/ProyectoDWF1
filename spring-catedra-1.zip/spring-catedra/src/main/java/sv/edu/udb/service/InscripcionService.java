/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.InscripcionRequest;
import sv.edu.udb.controller.response.InscripcionResponse;

public interface InscripcionService {
    Page<InscripcionResponse> findAllPaginated(Boolean activo, Long idCliente, Pageable pageable);
    InscripcionResponse findById(Long id);
    InscripcionResponse save(InscripcionRequest inscripcionRequest);
    InscripcionResponse update(Long id, InscripcionRequest inscripcionRequest);
    void delete(Long id);
}