package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.ReservaEspacioRequest;
import sv.edu.udb.controller.response.ReservaEspacioResponse;
import sv.edu.udb.exception.EspacioOcupadoException;
import sv.edu.udb.model.*;
import sv.edu.udb.repository.*;
import sv.edu.udb.service.ReservaEspacioService;
import sv.edu.udb.service.mapper.ReservaEspacioMapper;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReservaEspacioServiceImpl implements ReservaEspacioService {

    private final ReservaEspacioRepository reservaRepository;
    private final EspacioRepository espacioRepository;
    private final ClienteRepository clienteRepository;
    private final CotizacionRepository cotizacionRepository;
    private final ReservaEspacioMapper mapper;

    @Override
    @Transactional(readOnly = true)
    public Page<ReservaEspacioResponse> findAll(ReservaEspacio.EstadoReserva estado, Long idEspacio, Long idCliente, Pageable pageable) {
        Page<ReservaEspacio> page;

        if (estado != null) {
            page = reservaRepository.findByEstado(estado, pageable);
        } else if (idEspacio != null) {
            page = reservaRepository.findByEspacioId(idEspacio, pageable);
        } else if (idCliente != null) {
            page = reservaRepository.findByClienteId(idCliente, pageable);
        } else {
            page = reservaRepository.findAll(pageable);
        }

        return page.map(mapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public ReservaEspacioResponse findById(Long id) {
        return mapper.toResponse(findEntityById(id));
    }

    @Override
    @Transactional
    public ReservaEspacioResponse save(ReservaEspacioRequest request) {
        // Validar que no haya solapamiento
        validarDisponibilidad(
                request.getIdEspacio(),
                request.getFechaInicio(),
                request.getFechaFin(),
                request.getHoraInicio(),
                request.getHoraFin(),
                null
        );

        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));

        Espacio espacio = espacioRepository.findById(request.getIdEspacio())
                .orElseThrow(() -> new EntityNotFoundException("Espacio no encontrado con ID: " + request.getIdEspacio()));

        Cotizacion cotizacion = null;
        if (request.getIdCotizacion() != null) {
            cotizacion = cotizacionRepository.findById(request.getIdCotizacion())
                    .orElseThrow(() -> new EntityNotFoundException("Cotización no encontrada con ID: " + request.getIdCotizacion()));
        }

        ReservaEspacio reserva = ReservaEspacio.builder()
                .cliente(cliente)
                .espacio(espacio)
                .fechaInicio(request.getFechaInicio())
                .fechaFin(request.getFechaFin())
                .horaInicio(request.getHoraInicio())
                .horaFin(request.getHoraFin())
                .estado(request.getEstado())
                .precioTotal(request.getPrecioTotal())
                .cotizacion(cotizacion)
                .observaciones(request.getObservaciones())
                .build();

        return mapper.toResponse(reservaRepository.save(reserva));
    }

    @Override
    @Transactional
    public ReservaEspacioResponse update(Long id, ReservaEspacioRequest request) {
        ReservaEspacio reserva = findEntityById(id);

        // Validar solapamiento excluyendo la propia reserva
        validarDisponibilidad(
                request.getIdEspacio(),
                request.getFechaInicio(),
                request.getFechaFin(),
                request.getHoraInicio(),
                request.getHoraFin(),
                id
        );

        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));

        Espacio espacio = espacioRepository.findById(request.getIdEspacio())
                .orElseThrow(() -> new EntityNotFoundException("Espacio no encontrado con ID: " + request.getIdEspacio()));

        reserva.setCliente(cliente);
        reserva.setEspacio(espacio);
        reserva.setFechaInicio(request.getFechaInicio());
        reserva.setFechaFin(request.getFechaFin());
        reserva.setHoraInicio(request.getHoraInicio());
        reserva.setHoraFin(request.getHoraFin());
        reserva.setEstado(request.getEstado());
        reserva.setPrecioTotal(request.getPrecioTotal());
        reserva.setObservaciones(request.getObservaciones());

        if (request.getIdCotizacion() != null) {
            Cotizacion cotizacion = cotizacionRepository.findById(request.getIdCotizacion())
                    .orElseThrow(() -> new EntityNotFoundException("Cotización no encontrada"));
            reserva.setCotizacion(cotizacion);
        } else {
            reserva.setCotizacion(null);
        }

        return mapper.toResponse(reservaRepository.save(reserva));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!reservaRepository.existsById(id)) {
            throw new EntityNotFoundException("Reserva no encontrada con ID: " + id);
        }
        reservaRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean verificarDisponibilidad(Long idEspacio, LocalDate fechaInicio, LocalDate fechaFin,
                                           LocalTime horaInicio, LocalTime horaFin) {
        List<ReservaEspacio> solapamientos = reservaRepository.findSolapamientos(
                idEspacio, fechaInicio, fechaFin, horaInicio, horaFin, null);
        return solapamientos.isEmpty();
    }

    // ========== Validación de solapamiento ==========
    private void validarDisponibilidad(Long idEspacio, LocalDate fechaInicio, LocalDate fechaFin,
                                       LocalTime horaInicio, LocalTime horaFin, Long idExcluir) {

        List<ReservaEspacio> solapamientos = reservaRepository.findSolapamientos(
                idEspacio, fechaInicio, fechaFin, horaInicio, horaFin, idExcluir);

        if (!solapamientos.isEmpty()) {
            throw new EspacioOcupadoException(
                    "El espacio ya está reservado en el horario solicitado. Conflicto con la reserva ID: "
                            + solapamientos.get(0).getId());
        }
    }

    private ReservaEspacio findEntityById(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Reserva no encontrada con ID: " + id));
    }
}