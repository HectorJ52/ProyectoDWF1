package sv.edu.udb.implementation;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sv.edu.udb.controller.request.CotizacionRequest;
import sv.edu.udb.controller.response.CotizacionResponse;
import sv.edu.udb.model.Cliente;
import sv.edu.udb.model.Cotizacion;
import sv.edu.udb.repository.ClienteRepository;
import sv.edu.udb.repository.CotizacionRepository;
import sv.edu.udb.service.CotizacionService;
import sv.edu.udb.service.mapper.CotizacionMapper;

@Service
@RequiredArgsConstructor
public class CotizacionServiceImpl implements CotizacionService {

    private final CotizacionRepository cotizacionRepository;
    private final ClienteRepository clienteRepository;
    private final CotizacionMapper cotizacionMapper;

    @Override
    @Transactional(readOnly = true)
    public Page<CotizacionResponse> findAll(Cotizacion.EstadoCotizacion estado, Long idCliente, Pageable pageable) {
        Page<Cotizacion> page;

        if (estado != null) {
            page = cotizacionRepository.findByEstado(estado, pageable);
        } else if (idCliente != null) {
            Cliente cliente = clienteRepository.findById(idCliente)
                    .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + idCliente));
            page = cotizacionRepository.findByCliente(cliente, pageable);
        } else {
            page = cotizacionRepository.findAll(pageable);
        }

        return page.map(cotizacionMapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public CotizacionResponse findById(Long id) {
        Cotizacion cotizacion = cotizacionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cotización no encontrada con ID: " + id));
        return cotizacionMapper.toResponse(cotizacion);
    }

    @Override
    @Transactional
    public CotizacionResponse save(CotizacionRequest request) {
        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));

        Cotizacion cotizacion = Cotizacion.builder()
                .cliente(cliente)
                .estado(request.getEstado())
                .total(java.math.BigDecimal.ZERO)
                .observaciones(request.getObservaciones())
                .fechaRespuesta(request.getFechaRespuesta())
                .build();

        return cotizacionMapper.toResponse(cotizacionRepository.save(cotizacion));
    }

    @Override
    @Transactional
    public CotizacionResponse update(Long id, CotizacionRequest request) {
        Cotizacion cotizacion = cotizacionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cotización no encontrada con ID: " + id));

        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con ID: " + request.getIdCliente()));

        cotizacion.setCliente(cliente);
        cotizacion.setEstado(request.getEstado());
        cotizacion.setObservaciones(request.getObservaciones());
        cotizacion.setFechaRespuesta(request.getFechaRespuesta());

        return cotizacionMapper.toResponse(cotizacionRepository.save(cotizacion));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!cotizacionRepository.existsById(id)) {
            throw new EntityNotFoundException("Cotización no encontrada con ID: " + id);
        }
        cotizacionRepository.deleteById(id);
    }
}
