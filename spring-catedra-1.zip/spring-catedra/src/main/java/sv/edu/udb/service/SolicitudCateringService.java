package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.SolicitudCateringRequest;
import sv.edu.udb.controller.response.SolicitudCateringResponse;
import sv.edu.udb.model.SolicitudCatering.EstadoSolicitud;

public interface SolicitudCateringService {

    Page<SolicitudCateringResponse> findAll(EstadoSolicitud estado, Long idCliente, Long idServicio, Pageable pageable);

    SolicitudCateringResponse findById(Long id);

    SolicitudCateringResponse save(SolicitudCateringRequest request);

    SolicitudCateringResponse update(Long id, SolicitudCateringRequest request);

    void delete(Long id);
}