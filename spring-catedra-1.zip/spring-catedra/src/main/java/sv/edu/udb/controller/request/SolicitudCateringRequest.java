package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import sv.edu.udb.model.SolicitudCatering.EstadoSolicitud;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class SolicitudCateringRequest {

    @NotNull
    private Long idCliente;

    @NotNull
    private Long idServicio;

    @NotNull @Positive
    private Integer numeroAsistentes;

    private String menu;

    @NotNull
    private LocalDate fecha;

    @NotNull
    private LocalTime hora;

    @Size(max = 150)
    private String lugar;

    @NotNull
    private EstadoSolicitud estado;

    @NotNull @DecimalMin("0.0")
    private BigDecimal precioTotal;

    private Long idReservaEspacio;      // Opcional
    private Long idCotizacion;          // Opcional
}

