package sv.edu.udb.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import sv.edu.udb.model.SolicitudCatering;
import sv.edu.udb.model.SolicitudCatering.EstadoSolicitud;

public interface SolicitudCateringRepository extends JpaRepository<SolicitudCatering, Long> {

    Page<SolicitudCatering> findByClienteId(Long idCliente, Pageable pageable);

    Page<SolicitudCatering> findByEstado(EstadoSolicitud estado, Pageable pageable);

    Page<SolicitudCatering> findByServicioId(Long idServicio, Pageable pageable);
}
