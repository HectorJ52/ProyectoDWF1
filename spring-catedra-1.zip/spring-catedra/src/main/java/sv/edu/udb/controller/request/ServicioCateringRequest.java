package sv.edu.udb.controller.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class ServicioCateringRequest {
    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 100)
    private String nombre;

    private String descripcion;

    @NotNull @DecimalMin("0.0")
    private BigDecimal precioPersona;

    private Boolean activo = true;
}

