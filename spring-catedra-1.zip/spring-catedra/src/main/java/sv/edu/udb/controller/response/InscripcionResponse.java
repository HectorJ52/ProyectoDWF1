/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sv.edu.udb.controller.response;

import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
public class InscripcionResponse {
    private Long id;
    private Long idCliente;
    private String nombreCliente;
    private Long idCurso;
    private String nombreCurso;
    private Long idDiplomado;
    private String nombreDiplomado;
    private LocalDate fechaInscripcion;
    private String estado;
    private BigDecimal monto;
    private Boolean activo;
}
