package sv.edu.udb.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sv.edu.udb.controller.request.PagoRequest;
import sv.edu.udb.controller.response.PagoResponse;

public interface PagoService {

    Page<PagoResponse> findAll(Pageable pageable);

    PagoResponse findById(Long id);

    PagoResponse save(PagoRequest request);

    PagoResponse update(Long id, PagoRequest request);

    void delete(Long id);
}